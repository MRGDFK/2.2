package com.example.mrgdfk_techxquiz;

public class qna {

    public static String question[] = {
            "What is DAC?",
            "What is DAC used for?",
    };

    public static String choices [] [] = {
            {"Digital to Analog Converter","Diploma in Advanced Computing","Development Assistance Committee"},
            {"Audio Device","Provides Hi Res Audio","Sorround Sound Effect"},
    };

    public static String ca [] = {
            "Digital to Analog Converter",
            "Provides Hi Res Audio",
            "",
    };



}
